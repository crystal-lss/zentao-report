---
name: zentao-task-center
description: 禅道任务报告中心 — 从禅道 API 获取任务数据，自动生成静态 HTML 报告站点（FMS + GAS 双项目）。包含：主页仪表盘、按角色分类的详细任务页、延期任务追踪、团队效率分析、项目汇报（含核心需求跟踪/业务对接/风险预警）、趋势图表。Use when the user asks to generate Zentao task reports, update the task dashboard, or deploy the report site.
agent_created: true
---

# 禅道任务报告中心

## 概述

从禅道系统获取任务数据，自动生成一个完整的静态 HTML 报告站点，包含：

- **主页** (`index.html`) — FMS + GAS 双项目仪表盘，Tab 切换，趋势表，历史报告链接
- **按角色详情页** (`{project}/{date}/{角色}_详细任务.html`) — KPI 卡片 + Chart.js 图表 + 按人员折叠的任务明细
- **延期任务页** (`{project}/延期任务.html`) — 超期任务统计，按人员分组
- **效率分析页** (`{project}/效率分析.html`) — 团队产出工时分析，角色/人员效率
- **项目汇报页** (`{project}/项目汇报.html`) — 版本进度 + P0 需求跟踪 + 业务对接 + 风险预警

## 工作流程

### Step 1: 获取禅道任务数据

使用 **zentao-api** skill 获取各执行（迭代）的任务列表。需要为 `EXEC_MAP` 中的每个 execution 获取所有任务：

```
调用 zentao-api: GET /executions/{execution_id}/tasks?limit=200
```

将每个执行的任务 JSON 保存到 `/tmp/tasks_{execution_id}.json`。

execution IDs: 4519 (FMS-0630), 4562 (FMS-0615), 4651 (FMS-0715), 4527 (GAS-服务器迁移), 4639 (GAS-v4.5)

### Step 2: 运行生成器

```bash
python3 scripts/generate.py --data-dir /tmp/ --output-dir ./build/ [--today 2026-06-22]
```

参数说明：
- `--data-dir`：存放 tasks_*.json 的目录（默认 /tmp/）
- `--output-dir`：HTML 输出目录（如 ./build/）
- `--today`：统计日期，格式 YYYY-MM-DD（默认当天）

### Step 3: 部署（可选）

生成后输出目录结构：

```
build/
├── index.html           # 主中心
├── fms/
│   ├── index.html       # FMS 报告首页
│   ├── 项目汇报.html
│   ├── 延期任务.html
│   ├── 效率分析.html
│   └── 2026-06-22/
│       ├── 产品_详细任务.html
│       ├── 后端_详细任务.html
│       ├── 前端_详细任务.html
│       ├── 测试_详细任务.html
│       └── UI_UX_详细任务.html
└── gas/
    └── ... (同上结构)
```

可以使用 EdgeOne Pages 部署整个 `build/` 目录。

## 配置与定制

### 执行/迭代映射

EXEC_MAP 在 `scripts/generate.py` 中定义。新增或变更迭代时修改此映射：

```python
EXEC_MAP = {
    execution_id: (名称, 所属项目, 开始日期, 结束日期),
}
```

### 富内容数据

项目汇报页的静态内容（核心需求、业务对接、风险）定义在 `scripts/generate.py` 中：

- `CORE_REQUIREMENTS_FMS` — 核心需求跟踪（27 条）
- `BUSINESS_INTEGRATION_FMS` — 业务对接（6 项）
- `RISK_TRACKING_FMS` — 风险跟踪（5 条）

更新这些内容时直接修改对应列表，然后重新运行生成器。

详细数据格式见 `references/rich_content.md`。

### 趋势历史数据

`HIST_TOTALS_FMS` / `HIST_TOTALS_GAS` 记录每日任务数快照，用于趋势对比。

每日运行后，建议将当日数据追加到对应字典中。

### 任务类型映射

`CAT_MAP` 定义了禅道任务类型到报告角色的映射关系。新增任务类型时需在此添加。
