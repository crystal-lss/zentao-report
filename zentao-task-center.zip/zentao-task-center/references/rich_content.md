# 禅道任务中心 - 富内容数据

## 核心需求跟踪 (CORE_REQUIREMENTS_FMS)

27 条项目核心需求，按优先级(P0/P1/P2)和版本(0615/0630)分类。

更新方法：在 generate.py 中修改 `CORE_REQUIREMENTS_FMS` 列表。

格式：(优先级, 业务线, 需求编号, 总结描述, 版本, 状态)

## 业务与系统对接支持 (BUSINESS_INTEGRATION_FMS)

6 项业务对接跟踪。

更新方法：在 generate.py 中修改 `BUSINESS_INTEGRATION_FMS` 列表。

格式：(对接项, 类型, 状态, 说明)

## 风险与问题跟踪 (RISK_TRACKING_FMS)

5 条风险跟踪。

更新方法：在 generate.py 中修改 `RISK_TRACKING_FMS` 列表。

格式：(级别, 风险项, 问题描述, 应对措施)

## 任务类型 → 角色映射 (CAT_MAP)

```python
CAT_MAP = {
    '需求设计': '产品', '需求调研': '产品',
    'ab1_needs_research': '产品', 'ab2_request_des': '产品', 'ab3_request_check': '产品',
    'a_dev': '后端', 'a_dev4_control': '后端', 'Dev_Ops': '后端',
    'a_dev2_front': '前端',
    'ad1_UI_des': 'uiux',
    'ae2_test': '测试',
}
```

## 执行/迭代映射 (EXEC_MAP)

```python
EXEC_MAP = {
    4519: ('【2026】FMS-0630', 'FMS', '2026-04-30', '2026-06-30'),
    4562: ('【2026】FMS-0615', 'FMS', '2026-05-14', '2026-06-15'),
    4651: ('【2026】FMS-0715', 'FMS', '2026-06-15', '2026-07-15'),
    4527: ('【2026】海外售后服务器迁移-0630', 'GAS', '2026-04-20', '2026-06-30'),
    4639: ('【2026】海外售后v4.5-0630', 'GAS', '2026-06-11', '2026-06-30'),
}
```

## 趋势历史数据 (HIST_TOTALS_FMS / HIST_TOTALS_GAS)

手工维护的历史任务数量快照，用于趋势对比。
每日运行生成器后，应将当日数据追加到对应列表。
